FOV HRIDOY OPTIMIZER — NETLIFY BACKEND FIX

আপনার স্ক্রিনশটে netlify.app দেখা যাচ্ছে। আগের ZIP-এ Vercel-এর /api/analyze endpoint ছিল, তাই Netlify-তে সেটি পাওয়া যাচ্ছিল না এবং HTML/404 response-কে invalid response দেখাচ্ছিল।

এই ZIP-এ:
- Netlify Function যোগ করা হয়েছে: netlify/functions/analyze.js
- Frontend এখন /.netlify/functions/analyze?url=... endpoint ব্যবহার করে।
- netlify.toml-এ functions directory ও publish directory সেট করা আছে।
- PASTE ও manual input অপশন রাখা হয়েছে।
- আগের MP4 optimizer UI রাখা হয়েছে।

Deploy:
1. ZIP extract করুন।
2. Extract করা ফোল্ডারের ভেতরের সব ফাইল GitHub repository-র ROOT-এ upload করুন; index.html, netlify.toml এবং netlify/functions/analyze.js যেন root-এ থাকে।
3. Netlify-তে ওই repository connect করে deploy করুন।
4. Deploy শেষ হলে site refresh করে public TikTok link দিয়ে পরীক্ষা করুন।

মনে রাখবেন:
- Netlify function ঠিকভাবে deploy হলেও third-party TikTok data provider unavailable/rate-limited হলে checker error দেখাবে।
- Private/deleted/region-restricted video থেকে সব data পাওয়া যাবে না।
- Restriction flag official TikTok shadowban verdict নয়।
