// Vercel serverless function: server-to-server TikTok public-video analysis.
// The upstream host is fixed; user input is only ever sent as a TikTok URL.
const ALLOWED_HOSTS = new Set([
  'tiktok.com', 'www.tiktok.com', 'm.tiktok.com', 'vm.tiktok.com', 'vt.tiktok.com'
]);

function validTikTokUrl(value) {
  try {
    const u = new URL(value);
    return u.protocol === 'https:' &&
      ALLOWED_HOSTS.has(u.hostname.toLowerCase()) &&
      !u.username && !u.password && !u.port &&
      (u.hostname.toLowerCase() === 'vm.tiktok.com' || u.hostname.toLowerCase() === 'vt.tiktok.com' ||
       u.pathname.startsWith('/@') || u.pathname.startsWith('/t/') || u.pathname.startsWith('/v/'));
  } catch {
    return false;
  }
}

function finiteNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) && n >= 0 ? n : null;
}

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Access-Control-Allow-Methods', 'GET');
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed.' });

  const url = typeof req.query.url === 'string' ? req.query.url.trim() : '';
  if (!validTikTokUrl(url)) {
    return res.status(400).json({ error: 'A valid HTTPS TikTok video link is required.' });
  }

  const upstream = new URL('https://v2.voidaep.dev/api/proxy/tiktok/analyze');
  upstream.searchParams.set('url', url);
  // Probe is enabled by default upstream. Do not pass undocumented flags.

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 25000);
  try {
    const upstreamResponse = await fetch(upstream, {
      method: 'GET',
      headers: { Accept: 'application/json', 'User-Agent': 'FOV-HRIDOY-Optimizer/1.1' },
      signal: controller.signal,
      cache: 'no-store'
    });
    if (!upstreamResponse.ok) {
      const status = upstreamResponse.status;
      return res.status(status === 429 ? 503 : 502).json({
        error: status === 429 ? 'Analysis provider is rate-limited. Please wait and retry.' :
          `Analysis provider returned HTTP ${status}.`
      });
    }

    const data = await upstreamResponse.json();
    // This API may return HTTP 200 for missing/private videos; inspect its body.
    if (!data || data.id == null || Number(data.count || 0) < 1) {
      return res.status(404).json({ error: 'Video not found, private, unavailable, or not readable as a public post.' });
    }

    const browser = data.browserHD && typeof data.browserHD === 'object' ? data.browserHD : {};
    const tiers = Array.isArray(data.tiers) ? data.tiers : [];
    const sourceTier = tiers.find(t => t && t.gearName === 'play_addr') || null;
    const width = finiteNumber(browser.width ?? data.topWidth ?? sourceTier?.width);
    const height = finiteNumber(browser.height ?? data.topHeight ?? sourceTier?.height);
    const fps = finiteNumber(browser.fps ?? data.topFps ?? sourceTier?.fps);
    const duration = finiteNumber(data.duration);
    const health = data.health && typeof data.health === 'object' ? data.health : null;

    return res.status(200).json({
      ok: true,
      id: String(data.id),
      duration,
      width,
      height,
      fps: fps > 0 ? fps : null,
      fpsProbed: data.fpsProbed === true,
      isProhibited: typeof data.isProhibited === 'boolean' ? data.isProhibited : null,
      statusMsg: typeof data.statusMsg === 'string' ? data.statusMsg : null,
      views: finiteNumber(data.viewCount),
      likes: finiteNumber(data.likeCount),
      comments: finiteNumber(data.commentCount),
      shares: finiteNumber(data.shareCount),
      healthScore: health ? finiteNumber(health.score) : null,
      healthGrade: health && typeof health.grade === 'string' ? health.grade : null,
      healthSummary: health && typeof health.summary === 'string' ? health.summary : null,
      source: 'Void Studio TikTok Stats API'
    });
  } catch (error) {
    const message = error && error.name === 'AbortError' ? 'Analysis provider timed out.' :
      'Could not reach the analysis provider. Please retry later.';
    return res.status(502).json({ error: message });
  } finally {
    clearTimeout(timeout);
  }
};
