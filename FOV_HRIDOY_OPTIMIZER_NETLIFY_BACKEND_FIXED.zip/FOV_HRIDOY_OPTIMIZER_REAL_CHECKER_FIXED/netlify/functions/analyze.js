// Netlify Function: public TikTok video analysis proxy.
// Deploy this folder together with index.html. No browser-side API key is used.
const ALLOWED_HOSTS = new Set([
  'tiktok.com', 'www.tiktok.com', 'm.tiktok.com', 'vm.tiktok.com', 'vt.tiktok.com'
]);

function validTikTokUrl(value) {
  try {
    const u = new URL(value);
    const host = u.hostname.toLowerCase();
    return u.protocol === 'https:' &&
      ALLOWED_HOSTS.has(host) &&
      !u.username && !u.password && !u.port &&
      (host === 'vm.tiktok.com' || host === 'vt.tiktok.com' ||
       u.pathname.startsWith('/@') || u.pathname.startsWith('/t/') || u.pathname.startsWith('/v/'));
  } catch (_) { return false; }
}
function num(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 ? n : null;
}
function reply(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff'
    },
    body: JSON.stringify(body)
  };
}
exports.handler = async function(event) {
  if (event.httpMethod !== 'GET') return reply(405, { error: 'Method not allowed.' });
  const url = (event.queryStringParameters && event.queryStringParameters.url || '').trim();
  if (!validTikTokUrl(url)) return reply(400, { error: 'A valid HTTPS TikTok video link is required.' });

  const upstream = new URL('https://v2.voidaep.dev/api/proxy/tiktok/analyze');
  upstream.searchParams.set('url', url);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 25000);
  try {
    const response = await fetch(upstream.toString(), {
      method: 'GET',
      headers: { Accept: 'application/json', 'User-Agent': 'FOV-HRIDOY-Optimizer/1.2' },
      signal: controller.signal
    });
    if (!response.ok) {
      const status = response.status;
      return reply(status === 429 ? 503 : 502, {
        error: status === 429
          ? 'Analysis provider is rate-limited. Please wait and retry.'
          : 'Analysis provider returned HTTP ' + status + '.'
      });
    }
    const data = await response.json();
    if (!data || data.id == null || Number(data.count || 0) < 1) {
      return reply(404, { error: 'Video not found, private, unavailable, or not readable as a public post.' });
    }
    const browser = data.browserHD && typeof data.browserHD === 'object' ? data.browserHD : {};
    const tiers = Array.isArray(data.tiers) ? data.tiers : [];
    const play = tiers.find(t => t && t.gearName === 'play_addr') || {};
    const width = num(browser.width ?? data.topWidth ?? play.width);
    const height = num(browser.height ?? data.topHeight ?? play.height);
    const fps = num(browser.fps ?? data.topFps ?? play.fps);
    const health = data.health && typeof data.health === 'object' ? data.health : null;
    return reply(200, {
      ok: true,
      id: String(data.id),
      duration: num(data.duration),
      width, height, fps: fps > 0 ? fps : null,
      fpsProbed: data.fpsProbed === true,
      isProhibited: typeof data.isProhibited === 'boolean' ? data.isProhibited : null,
      statusMsg: typeof data.statusMsg === 'string' ? data.statusMsg : null,
      views: num(data.viewCount), likes: num(data.likeCount),
      comments: num(data.commentCount), shares: num(data.shareCount),
      healthScore: health ? num(health.score) : null,
      healthGrade: health && typeof health.grade === 'string' ? health.grade : null,
      healthSummary: health && typeof health.summary === 'string' ? health.summary : null,
      source: 'Void Studio TikTok Stats API'
    });
  } catch (err) {
    return reply(502, {
      error: err && err.name === 'AbortError'
        ? 'Analysis provider timed out.'
        : 'Could not reach the analysis provider. Please retry later.'
    });
  } finally {
    clearTimeout(timer);
  }
};
